# The Sent Word - Spoken Word Ministry Website

## Overview

The Sent Word is a professional website for Arthur Ayotte, a spoken word artist and Christian storyteller. The application is built as a modern web platform that showcases Arthur's services, portfolio, and provides contact/booking functionality for ministries and Christian content creators.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with custom ministry-themed color palette
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **State Management**: TanStack Query (React Query) for server state
- **Build Tool**: Vite for development and bundling

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ESM modules
- **Data Layer**: Currently using in-memory storage with interface for future database integration
- **API Design**: RESTful endpoints for contact forms and booking inquiries
- **Error Handling**: Centralized error middleware with structured responses

### Database Design
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Database**: PostgreSQL (Neon serverless) - configured but not yet implemented
- **Schema**: Two main tables - contacts and booking_inquiries with proper validation
- **Migrations**: Drizzle Kit for schema management

## Key Components

### Frontend Components
- **Navigation**: Fixed header with smooth scrolling to sections
- **Hero**: Landing section with call-to-action buttons
- **About**: Arthur's background and mission statement
- **Services**: Three main offerings with pricing and booking modals
- **Portfolio**: Showcase of recent work and performances
- **Testimonials**: Client feedback with star ratings
- **Contact**: Contact form with service selection
- **BookingModal**: Dedicated booking inquiry form

### Backend Services
- **Contact API**: Handles general contact form submissions
- **Booking API**: Manages service-specific booking inquiries
- **Storage Layer**: Abstracted interface supporting both memory and database storage
- **Validation**: Zod schemas for type-safe data validation

### Services Offered
1. **Custom Spoken Word** ($75) - Original pieces based on client themes
2. **Live Performance** ($150 in-person, $100 video) - Speaking engagements
3. **Video Editing** ($25) - Short-form content for social media

## Data Flow

1. **User Interaction**: Users browse services and submit contact/booking forms
2. **Form Validation**: Client-side validation with Zod schemas
3. **API Requests**: TanStack Query manages API calls with error handling
4. **Server Processing**: Express routes validate and store form data
5. **Response Handling**: Success/error feedback via toast notifications
6. **Future Email Integration**: Placeholder for Nodemailer email notifications

## External Dependencies

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework
- **Radix UI**: Headless component primitives
- **Lucide React**: Icon library
- **Google Fonts**: Playfair Display and Inter fonts

### State and Data Management
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form handling with validation
- **Zod**: Runtime type validation

### Development Tools
- **TypeScript**: Type safety across the stack
- **Vite**: Fast development server and build tool
- **ESBuild**: Backend bundling for production
- **Drizzle Kit**: Database schema management

## Deployment Strategy

### Development Environment
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx for TypeScript execution
- **Database**: PostgreSQL via Neon serverless (configured)

### Production Build
- **Frontend**: Static assets built to `dist/public`
- **Backend**: Bundled to `dist/index.js` with external dependencies
- **Deployment**: Single server setup serving both frontend and API

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **NODE_ENV**: Environment flag for conditional features
- **REPL_ID**: Replit-specific development features

The application follows a clean separation of concerns with a shared schema layer between frontend and backend, ensuring type safety and consistency across the full stack. The architecture supports easy migration from in-memory storage to PostgreSQL database when ready for production deployment.

## Recent Changes

### January 26, 2025
- **Removed Testimonials Section**: Completely removed testimonials component and navigation links per user request
- **Modernized Design**: Updated all components with modern gradients, rounded corners, better spacing, and contemporary styling
- **Removed Photos and Portfolio Section**: Removed portfolio component and photos from about section
- **External Portfolio Link**: Updated navigation and footer to link to user's Canva portfolio (https://www.canva.com/design/DAGWHPaWBXQ/...)
- **Streamlined Layout**: Site now flows: Hero → About → Services → Contact for cleaner user experience