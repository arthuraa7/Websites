import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Mail, MapPin, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Contact() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    service: "",
    message: ""
  });

  const contactMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message sent successfully!",
        description: "Thank you for your message. I will get back to you soon.",
      });
      setFormData({ name: "", email: "", service: "", message: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error sending message",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    contactMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section id="contact" className="py-24 bg-white">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-20">
          <h2 className="font-playfair text-5xl md:text-6xl font-bold text-slate-900 mb-6">Let's Create Something Impactful</h2>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto mb-8 rounded-full"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to share God's message through powerful spoken word? Reach out today.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Live Performance Booking - Main Focus */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 p-10 rounded-3xl shadow-2xl border border-blue-100">
              <h3 className="font-playfair text-3xl font-bold mb-6 text-slate-900">🎙️ Book a Live Performance</h3>
              <div className="space-y-6">
                <div className="bg-white p-6 rounded-2xl shadow-lg">
                  <h4 className="font-semibold text-xl mb-3 text-slate-800">In-Person Performance</h4>
                  <p className="text-gray-700 mb-2">Starting at <span className="font-bold text-blue-600">$70</span> (North GA)</p>
                  <p className="text-gray-600">Live performance by Arthur with passion, prayer, and unforgettable impact. Includes pre-event consultation and tech coordination.</p>
                </div>
                
                <div className="bg-white p-6 rounded-2xl shadow-lg">
                  <h4 className="font-semibold text-xl mb-3 text-slate-800">Virtual Performance</h4>
                  <p className="text-gray-700 mb-2">Starting at <span className="font-bold text-purple-600">$60</span></p>
                  <p className="text-gray-600">High-quality virtual performance delivered with the same energy and ministry impact as in-person events.</p>
                </div>


              </div>
            </div>

            {/* General Contact Form */}
            <div className="bg-gradient-to-br from-gray-50 to-white p-10 rounded-3xl shadow-2xl border border-gray-100">
              <h3 className="font-playfair text-3xl font-bold mb-8 text-slate-900">Have Questions? Get in Touch</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Name *</label>
                <Input
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  required
                  className="focus:border-ministry-accent focus:ring-ministry-accent"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  required
                  className="focus:border-ministry-accent focus:ring-ministry-accent"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Service Interested In</label>
                <Select value={formData.service} onValueChange={(value) => handleInputChange("service", value)}>
                  <SelectTrigger className="focus:border-ministry-accent focus:ring-ministry-accent">
                    <SelectValue placeholder="Select a service" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="custom-spoken-word">Custom Spoken Word</SelectItem>
                    <SelectItem value="performance">Performance Booking</SelectItem>
                    <SelectItem value="video-editing">Video Editing</SelectItem>
                    <SelectItem value="general">General Inquiry</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Message *</label>
                <Textarea
                  value={formData.message}
                  onChange={(e) => handleInputChange("message", e.target.value)}
                  required
                  rows={4}
                  placeholder="Tell me about your project or event..."
                  className="focus:border-ministry-accent focus:ring-ministry-accent"
                />
              </div>
              <Button 
                type="submit" 
                disabled={contactMutation.isPending}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-5 rounded-2xl font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-xl"
              >
                {contactMutation.isPending ? "Sending..." : "Send Message"}
              </Button>
            </form>
            </div>
          </div>
          
          {/* Contact Information Sidebar */}
          <div className="space-y-8">
            <div>
              <h3 className="font-playfair text-2xl font-bold mb-6 text-slate-900">Contact Info</h3>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-12 h-12 bg-ministry-accent rounded-lg flex items-center justify-center text-white mr-4">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-ministry-dark mb-1">Primary Email</h4>
                    <a href="mailto:arthurayotteaa@gmail.com" className="text-ministry-accent hover:underline">arthurayotteaa@gmail.com</a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-12 h-12 bg-ministry-accent rounded-lg flex items-center justify-center text-white mr-4">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-ministry-dark mb-1">Business Email</h4>
                    <a href="mailto:Arthur.thesentword@gmail.com" className="text-ministry-accent hover:underline">Arthur.thesentword@gmail.com</a>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-12 h-12 bg-ministry-accent rounded-lg flex items-center justify-center text-white mr-4">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-ministry-dark mb-1">Location</h4>
                    <p className="text-gray-600">North Georgia | Available for travel and virtual projects</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Quick Consultation */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-6 rounded-3xl shadow-2xl">
              <h4 className="font-playfair text-xl font-bold mb-4">Need to Discuss First?</h4>
              <p className="text-gray-300 mb-4">Schedule a consultation to plan your event</p>
              <a 
                href="mailto:arthurayotteaa@gmail.com?subject=Booking%20The%20Sent%20Word" 
                className="inline-block w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-2xl font-semibold transition-all duration-300 shadow-xl text-center"
              >
                <Calendar className="w-4 h-4 inline mr-2" />
                Schedule Consultation
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
