export default function About() {
  return (
    <section id="about" className="py-24 bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-20">
          <h2 className="font-playfair text-5xl md:text-6xl font-bold text-slate-900 mb-6">About Arthur</h2>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto mb-8 rounded-full"></div>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="space-y-8">
            <p className="text-xl leading-relaxed text-gray-700">
              I'm Arthur Ayotte — a spoken word artist, Christian storyteller, and creative with a mission. I help Christian ministries, speakers, and content creators grow their impact through performed and written spoken word, and short-form content for platforms like Pinterest and YouTube Shorts.
            </p>
            <p className="text-xl leading-relaxed text-gray-700">
              Whether on stage or behind the screen, my goal is to glorify God and deliver His message with power and excellence. Every word I craft and every performance I give is designed to touch hearts and transform lives.
            </p>
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-8 rounded-2xl border border-blue-100">
              <p className="text-xl italic text-slate-800 font-medium mb-4">
                "So is my word that goes out from my mouth: It will not return to me empty…"
              </p>
              <p className="text-right text-sm text-gray-600">— Isaiah 55:11</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
