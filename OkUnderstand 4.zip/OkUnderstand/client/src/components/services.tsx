import { PenTool, Mic, Video } from "lucide-react";

interface ServicesProps {
  onBookService: (service: string) => void;
}

export default function Services({ onBookService }: ServicesProps) {
  const services = [
    {
      id: "custom-spoken-word",
      icon: <PenTool className="w-8 h-8" />,
      title: "Custom Spoken Word Creation",
      description: "A custom-written, original spoken word piece tailored to your event, theme, or message. Prayerfully written to reflect the heart of your ministry.",
      price: "Starting at $45",
      buttonText: "Request Quote"
    },
    {
      id: "performance",
      icon: <Mic className="w-8 h-8" />,
      title: "Live or Virtual Performance",
      description: "A live performance by Arthur of your custom or existing spoken word piece. Delivered with passion, prayer, and unforgettable impact.",
      price: "In-person: $70 | Virtual: $60",
      buttonText: "Book Performance"
    },
    {
      id: "video-production",
      icon: <Video className="w-8 h-8" />,
      title: "Short-Form Video Production",
      description: "Professionally edited 15-60 second gospel-centered videos with cuts, transitions, music, and text overlays designed for maximum engagement.",
      price: "Starting at $30 per video",
      buttonText: "Get Started"
    }
  ];

  return (
    <section id="services" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-20">
          <h2 className="font-playfair text-5xl md:text-6xl font-bold text-slate-900 mb-6">Services</h2>
          <div className="w-32 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto mb-8 rounded-full"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Transforming messages into powerful spoken word experiences that inspire and impact
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => (
            <div key={service.id} className={`relative group bg-gradient-to-br ${
              index === 0 ? 'from-blue-500 to-blue-600' : 
              index === 1 ? 'from-purple-500 to-purple-600' : 
              'from-indigo-500 to-indigo-600'
            } rounded-3xl p-8 text-white shadow-2xl hover:shadow-3xl transition-all duration-500 transform hover:-translate-y-4 hover:scale-105`}>
              <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent rounded-3xl"></div>
              <div className="relative z-10">
                <div className="mb-6 p-3 bg-white/20 backdrop-blur-sm rounded-2xl w-fit">
                  {service.icon}
                </div>
                <h3 className="font-playfair text-2xl font-bold mb-4">{service.title}</h3>
                <p className="text-white/90 mb-6 leading-relaxed">
                  {service.description}
                </p>
                <div className="text-white font-bold text-xl mb-6">{service.price}</div>
                <div className="space-y-3">
                  <button 
                    onClick={() => onBookService(service.id)}
                    className="w-full bg-white/20 hover:bg-white hover:text-slate-900 backdrop-blur-sm text-white py-4 rounded-2xl transition-all duration-300 font-semibold border border-white/30"
                  >
                    {service.buttonText}
                  </button>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <a 
                      href="https://paypal.me/ArthurAyotte?locale.x=en_US&country.x=US" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-[#0070ba] hover:bg-[#005ea6] text-white py-2 px-4 rounded-xl text-sm font-semibold text-center transition-all duration-300"
                    >
                      PayPal
                    </a>
                    
                    <a 
                      href="https://cash.app/$Arthurayottesent" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-[#00d632] hover:bg-[#00c92e] text-white py-2 px-4 rounded-xl text-sm font-semibold text-center transition-all duration-300"
                    >
                      Cash App
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
