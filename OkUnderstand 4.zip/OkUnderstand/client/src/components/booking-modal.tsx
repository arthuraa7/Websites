import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedService: string;
}

export default function BookingModal({ isOpen, onClose, selectedService }: BookingModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    service: "",
    projectDetails: ""
  });

  const getServiceName = (serviceId: string) => {
    switch(serviceId) {
      case 'custom-spoken-word':
        return 'Custom Spoken Word ($75)';
      case 'performance':
        return 'Spoken Word Performance ($150/$100)';
      case 'video-editing':
        return 'Short-Form Video Editing ($25)';
      default:
        return serviceId;
    }
  };

  const bookingMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/booking", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking inquiry sent successfully!",
        description: "Thank you for your inquiry. I will get back to you soon with more details.",
      });
      setFormData({ name: "", email: "", service: "", projectDetails: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error sending inquiry",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) {
      toast({
        title: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    const submissionData = {
      ...formData,
      service: getServiceName(selectedService)
    };
    
    bookingMutation.mutate(submissionData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg bg-white rounded-3xl border-0 shadow-2xl">
        <DialogHeader>
          <DialogTitle className="font-playfair text-3xl font-bold text-slate-900">Book Service</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Service</label>
            <Input
              value={getServiceName(selectedService)}
              readOnly
              className="bg-gray-50"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Name *</label>
            <Input
              value={formData.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
              required
              className="focus:border-ministry-accent focus:ring-ministry-accent"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
            <Input
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange("email", e.target.value)}
              required
              className="focus:border-ministry-accent focus:ring-ministry-accent"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Project Details</label>
            <Textarea
              value={formData.projectDetails}
              onChange={(e) => handleInputChange("projectDetails", e.target.value)}
              rows={3}
              placeholder="Tell me about your project..."
              className="focus:border-ministry-accent focus:ring-ministry-accent"
            />
          </div>
          <Button 
            type="submit" 
            disabled={bookingMutation.isPending}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-4 rounded-2xl font-semibold text-lg transition-all duration-300 transform hover:scale-105 shadow-xl"
          >
            {bookingMutation.isPending ? "Sending..." : "Send Inquiry"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
