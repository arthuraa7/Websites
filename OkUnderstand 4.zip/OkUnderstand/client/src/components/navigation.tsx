import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsMenuOpen(false);
    }
  };

  return (
    <nav className={`fixed w-full top-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-ministry-dark/95' : 'bg-ministry-dark'} text-white shadow-lg`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <span className="font-playfair text-xl font-bold">The Sent Word</span>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <button onClick={() => scrollToSection('home')} className="hover:text-ministry-accent transition-colors duration-300">Home</button>
              <button onClick={() => scrollToSection('about')} className="hover:text-ministry-accent transition-colors duration-300">About</button>
              <button onClick={() => scrollToSection('services')} className="hover:text-ministry-accent transition-colors duration-300">Services</button>
              <a href="https://www.canva.com/design/DAGWHPaWBXQ/MyF0D-HZ4FP2wwOrNPaGEw/view?utm_content=DAGWHPaWBXQ&utm_campaign=designshare&utm_medium=link2&utm_source=uniquelinks&utlId=hf9bfad63f9" target="_blank" rel="noopener noreferrer" className="hover:text-ministry-accent transition-colors duration-300">Portfolio</a>
              <button onClick={() => scrollToSection('contact')} className="hover:text-ministry-accent transition-colors duration-300">Contact</button>
            </div>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-white hover:text-ministry-accent focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Navigation Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-ministry-gray">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <button onClick={() => scrollToSection('home')} className="block w-full text-left px-3 py-2 text-white hover:text-ministry-accent transition-colors">Home</button>
            <button onClick={() => scrollToSection('about')} className="block w-full text-left px-3 py-2 text-white hover:text-ministry-accent transition-colors">About</button>
            <button onClick={() => scrollToSection('services')} className="block w-full text-left px-3 py-2 text-white hover:text-ministry-accent transition-colors">Services</button>
            <a href="https://www.canva.com/design/DAGWHPaWBXQ/MyF0D-HZ4FP2wwOrNPaGEw/view?utm_content=DAGWHPaWBXQ&utm_campaign=designshare&utm_medium=link2&utm_source=uniquelinks&utlId=hf9bfad63f9" target="_blank" rel="noopener noreferrer" className="block w-full text-left px-3 py-2 text-white hover:text-ministry-accent transition-colors">Portfolio</a>
            <button onClick={() => scrollToSection('contact')} className="block w-full text-left px-3 py-2 text-white hover:text-ministry-accent transition-colors">Contact</button>
          </div>
        </div>
      )}
    </nav>
  );
}
