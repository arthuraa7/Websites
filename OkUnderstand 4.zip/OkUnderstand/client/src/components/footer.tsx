import { Link } from "wouter";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          <div>
            <h3 className="font-playfair text-3xl font-bold mb-6 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">The Sent Word</h3>
            <p className="text-gray-300 leading-relaxed text-lg">
              Transforming hearts and minds through the power of spoken word ministry.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-gray-300">
              <li><button onClick={() => scrollToSection('about')} className="hover:text-ministry-accent transition-colors">About</button></li>
              <li><button onClick={() => scrollToSection('services')} className="hover:text-ministry-accent transition-colors">Services</button></li>
              <li><a href="https://www.canva.com/design/DAGWHPaWBXQ/MyF0D-HZ4FP2wwOrNPaGEw/view?utm_content=DAGWHPaWBXQ&utm_campaign=designshare&utm_medium=link2&utm_source=uniquelinks&utlId=hf9bfad63f9" target="_blank" rel="noopener noreferrer" className="hover:text-ministry-accent transition-colors">Portfolio</a></li>
              <li><button onClick={() => scrollToSection('contact')} className="hover:text-ministry-accent transition-colors">Contact</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-2 text-gray-300">
              <li>Custom Spoken Word</li>
              <li>Live Performances</li>
              <li>Video Editing</li>
              <li>Ministry Consultation</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-300 text-lg">
              &copy; 2025 The Sent Word | Spoken Word by Arthur Ayotte | 
              <span className="italic text-gray-400"> "His word will not return empty" - Isaiah 55:11</span>
            </p>
            <div className="flex gap-6 text-gray-400">
              <Link href="/privacy-policy" className="hover:text-ministry-accent transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms-of-service" className="hover:text-ministry-accent transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
