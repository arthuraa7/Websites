import Navigation from "../components/navigation";
import Hero from "../components/hero";
import About from "../components/about";
import Services from "../components/services";
import Contact from "../components/contact";
import Footer from "../components/footer";
import BookingModal from "../components/booking-modal";
import { useState } from "react";

export default function Home() {
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState("");

  const openBookingModal = (service: string) => {
    setSelectedService(service);
    setIsBookingModalOpen(true);
  };

  const closeBookingModal = () => {
    setIsBookingModalOpen(false);
    setSelectedService("");
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <Hero />
      <About />
      <Services onBookService={openBookingModal} />
      <Contact />
      <Footer />
      <BookingModal 
        isOpen={isBookingModalOpen}
        onClose={closeBookingModal}
        selectedService={selectedService}
      />
    </div>
  );
}
