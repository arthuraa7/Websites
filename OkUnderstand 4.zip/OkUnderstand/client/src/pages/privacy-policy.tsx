import { Link } from "wouter";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium">
              ← Back to Home
            </Link>
          </div>
          
          <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
            <h1 className="font-playfair text-4xl font-bold mb-8 text-slate-900">Privacy Policy</h1>
            <p className="text-gray-600 mb-8">Last updated: January 26, 2025</p>

            <div className="space-y-8 text-gray-700 leading-relaxed">
              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Information We Collect</h2>
                <p className="mb-4">
                  When you contact us or book our services, we may collect the following information:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Name and contact information (email address, phone number)</li>
                  <li>Organization or ministry details</li>
                  <li>Event information and service requirements</li>
                  <li>Payment information (processed securely through PayPal and Cash App)</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">How We Use Your Information</h2>
                <p className="mb-4">We use the information we collect to:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Provide and deliver our spoken word services</li>
                  <li>Communicate about your booking and service requirements</li>
                  <li>Process payments for our services</li>
                  <li>Send follow-up communications related to your service</li>
                  <li>Improve our services and customer experience</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Information Sharing</h2>
                <p className="mb-4">
                  We do not sell, trade, or otherwise transfer your personal information to third parties, except:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>To process payments through our secure payment partners (PayPal, Cash App)</li>
                  <li>When required by law or to protect our rights</li>
                  <li>With your explicit consent</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Payment Processing</h2>
                <p>
                  We use PayPal and Cash App for payment processing. These services have their own privacy policies 
                  and security measures. We do not store your payment information on our servers.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Data Security</h2>
                <p>
                  We implement appropriate security measures to protect your personal information against 
                  unauthorized access, alteration, disclosure, or destruction.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Your Rights</h2>
                <p className="mb-4">You have the right to:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Request access to your personal information</li>
                  <li>Request correction of inaccurate information</li>
                  <li>Request deletion of your information</li>
                  <li>Opt out of future communications</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Contact Us</h2>
                <p>
                  If you have questions about this Privacy Policy, please contact us at:{" "}
                  <a href="mailto:arthurayotteaa@gmail.com" className="text-blue-600 hover:text-blue-800">
                    arthurayotteaa@gmail.com
                  </a>
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Changes to This Policy</h2>
                <p>
                  We may update this Privacy Policy from time to time. We will notify you of any changes 
                  by posting the new Privacy Policy on this page with an updated date.
                </p>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}