import { Link } from "wouter";

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-blue-600 hover:text-blue-800 font-medium">
              ← Back to Home
            </Link>
          </div>
          
          <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
            <h1 className="font-playfair text-4xl font-bold mb-8 text-slate-900">Terms of Service</h1>
            <p className="text-gray-600 mb-8">Last updated: January 26, 2025</p>

            <div className="space-y-8 text-gray-700 leading-relaxed">
              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Agreement to Terms</h2>
                <p>
                  By accessing and using The Sent Word services, you agree to be bound by these Terms of Service 
                  and all applicable laws and regulations. If you do not agree with any of these terms, 
                  you are prohibited from using our services.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Services Provided</h2>
                <p className="mb-4">The Sent Word offers the following services:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li><strong>Custom Spoken Word Creation</strong> - Starting at $45</li>
                  <li><strong>Live Performance (In-person)</strong> - Starting at $70</li>
                  <li><strong>Virtual Performance</strong> - Starting at $60</li>
                  <li><strong>Short-Form Video Production</strong> - Starting at $30 per video</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Booking and Payment</h2>
                <div className="space-y-4">
                  <p>
                    <strong>Booking Process:</strong> Services must be booked through our contact form or direct communication. 
                    A deposit may be required to secure your booking date.
                  </p>
                  <p>
                    <strong>Payment:</strong> We accept payments through PayPal (paypal.me/ArthurAyotte) and Cash App ($Arthurayottesent). 
                    Payment terms will be discussed during the booking process.
                  </p>
                  <p>
                    <strong>Cancellation:</strong> Cancellations must be made at least 48 hours before the scheduled service. 
                    Deposits may be non-refundable depending on the circumstances.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Intellectual Property</h2>
                <p className="mb-4">
                  All custom spoken word pieces created by Arthur Ayotte remain the intellectual property of The Sent Word unless 
                  otherwise agreed upon in writing. Clients receive usage rights for their specific event or ministry purpose.
                </p>
                <p>
                  Clients may not redistribute, sell, or use the content for commercial purposes beyond the agreed scope 
                  without written permission.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Performance Requirements</h2>
                <div className="space-y-4">
                  <p>
                    <strong>In-Person Events:</strong> Client is responsible for providing appropriate sound equipment, 
                    staging, and technical support as discussed during booking.
                  </p>
                  <p>
                    <strong>Virtual Events:</strong> Client must provide necessary technical details (platform, access information) 
                    at least 24 hours before the event.
                  </p>
                  <p>
                    <strong>Travel:</strong> For events outside North Georgia, additional travel expenses may apply and 
                    will be discussed during booking.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Content Standards</h2>
                <p>
                  All content created and performed by The Sent Word aligns with Christian values and biblical principles. 
                  We reserve the right to decline projects that conflict with our ministry mission and values.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Limitation of Liability</h2>
                <p>
                  The Sent Word shall not be liable for any indirect, incidental, special, or consequential damages 
                  resulting from the use of our services. Our total liability is limited to the amount paid for services.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Force Majeure</h2>
                <p>
                  We are not responsible for delays or failure to perform due to circumstances beyond our control, 
                  including but not limited to natural disasters, illness, or government regulations.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Modifications</h2>
                <p>
                  These terms may be updated at any time. Continued use of our services after changes constitutes 
                  acceptance of the new terms.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Contact Information</h2>
                <p>
                  For questions about these Terms of Service, please contact us at:{" "}
                  <a href="mailto:arthurayotteaa@gmail.com" className="text-blue-600 hover:text-blue-800">
                    arthurayotteaa@gmail.com
                  </a>
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4 text-slate-800">Governing Law</h2>
                <p>
                  These terms are governed by the laws of the State of Georgia, United States. 
                  Any disputes will be resolved in the courts of Georgia.
                </p>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}